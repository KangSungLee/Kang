let A = 1
let B = 2
console.log(A)
console.log(B)
console.log(A+B)
