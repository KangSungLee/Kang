let hello = 'Hello World!';
console.log(hello)