let a = 'Hello world!!!';
a += "자바" + '스크립트';  // a = a + "자바" + '스크립트';
console.log(a);